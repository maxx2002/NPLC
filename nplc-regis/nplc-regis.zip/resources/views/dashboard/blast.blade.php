@extends('dashboard.layouts.main')

@section('container')

<h3 class="mt-3">Email Sent Successfully</h3>

@endsection


<?php $__env->startSection('container'); ?>

<h1 class="mt-4">Daftar Sekolah</h1>

    <table class="table table-bordered mt-4">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Sekolah</th>
                <th>Alamat Sekolah</th>
                <th>Kota Sekolah</th>
                <th>No Telp Sekolah</th>
            </tr>
        </thead>
        <tbody>
            <?php ($no=1); ?>
            <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->nama_sekolah); ?></td>
                <td><?php echo e($data->alamat_sekolah); ?></td>
                <td><?php echo e($data->kota_sekolah); ?></td>
                <td><?php echo e($data->no_sekolah); ?></td>               
            </tr>                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-end">
        <?php echo e($school->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/dashboard/registration/school.blade.php ENDPATH**/ ?>


<?php $__env->startSection('container'); ?>

<h1 class="mt-4">Team <?php echo e($team->nama_tim); ?></h1>

<table class="table table-bordered mt-4">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Kota</th>
            <th>Kode Pos</th>
            <th>Nomor WA</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php ($no=1); ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->gender); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->alamat); ?></td> 
            <td><?php echo e($data->kota); ?></td> 
            <td><?php echo e($data->kode_pos); ?></td> 
            <td><?php echo e($data->no_wa); ?></td> 
            <td>
                <a href="" class="btn btn-sm btn-warning">Edit</a>                           
            </td>               
        </tr>                
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\nplc-regis\resources\views/dashboard/registration/member.blade.php ENDPATH**/ ?>
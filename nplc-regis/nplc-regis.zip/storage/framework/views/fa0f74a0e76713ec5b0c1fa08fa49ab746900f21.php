<?php $__env->startComponent('mail::message'); ?>
# Dear Team Members of <?php echo e($team['nama_tim']); ?><br>
# Your team id is <?php echo e($team['id_tim']); ?>


Thank you for registering as a participant on the 9th NPLC

<?php ($i = 1); ?>
<?php $__currentLoopData = $count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item->verified == 'yes'): ?>
        <?php ($i++); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($i <= 50): ?>
    Congratulations, your registration fee is free
<?php endif; ?>

<?php $__env->startComponent('mail::table'); ?>
| Competition Category     | Region               
| :----------------------: | :-------------------: 
| <?php echo e($team['kategori']); ?>  | <?php echo e($team['region']); ?> 
<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::table'); ?>
| School Name                    | School Address                  | School City                   | School Phone
| :----------------------------: | :-----------------------------: | :---------------------------: | :-------------------------:
| <?php echo e($school['nama_sekolah']); ?>  | <?php echo e($school['alamat_sekolah']); ?> | <?php echo e($school['kota_sekolah']); ?> | <?php echo e($school['no_sekolah']); ?>

<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::table'); ?>
| Team Name               | Coach Name                 | Coach Email                | Coach Phone
| :---------------------: | :------------------------: | :-------------------------:| :-------------------------:
| <?php echo e($team['nama_tim']); ?> | <?php echo e($team['nama_coach']); ?>  | <?php echo e($team['email_coach']); ?> | <?php echo e($team['no_coach']); ?>

<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::table'); ?>
| Name                   | Gender                    | Email                   | Phone                   | Address                  | City                   | Zip Code
| :--------------------: | :-----------------------: | :---------------------: | :---------------------: | :----------------------: | :--------------------: | :-----------------------:
| <?php echo e($leader['nama']); ?>  | <?php echo e($leader['gender']); ?>   | <?php echo e($leader['email']); ?>   | <?php echo e($leader['no_wa']); ?>  | <?php echo e($leader['alamat']); ?>  | <?php echo e($leader['kota']); ?>  | <?php echo e($leader['kode_pos']); ?>

| <?php echo e($member1['nama']); ?> | <?php echo e($member1['gender']); ?>  | <?php echo e($member1['email']); ?>  | <?php echo e($member1['no_wa']); ?> | <?php echo e($member1['alamat']); ?> | <?php echo e($member1['kota']); ?> | <?php echo e($member1['kode_pos']); ?>

| <?php echo e($member2['nama']); ?> | <?php echo e($member2['gender']); ?>  | <?php echo e($member2['email']); ?>  | <?php echo e($member2['no_wa']); ?> | <?php echo e($member2['alamat']); ?> | <?php echo e($member2['kota']); ?> | <?php echo e($member2['kode_pos']); ?>

<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

If the data that you've submitted is correct, please continue by filling out the verification form below.
<?php $__env->startComponent('mail::button', ['url' => 'https://docs.google.com/forms/d/e/1FAIpQLScTnOlXREAutQQn_ymchTKjJ5Briwh0SDjqYKwyI6Ke6s2LLQ/viewform']); ?>
Verification Form
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
9th NPLC's Committee.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/email/sendemail.blade.php ENDPATH**/ ?>


<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Welcome back, <?php echo e(Auth::user()->name); ?></h1>    
</div>

<?php ($i = 0); ?>
<?php ($j = 0); ?>
<?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($i++); ?>
    <?php if($item->verified === "yes"): ?>
      <?php ($j++); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row">
    <div class="col-sm-4">
      <div class="card bg-light shadow-sm mt-2">
        <div class="card-body">
          <h5 class="card-title">Total Teams</h5>
          <h6 class="card-text"><?php echo e($i); ?></h6>
          <a href="/dashboard/team" class="btn btn-primary">View Teams</a>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
        <div class="card bg-light shadow-sm mt-2">
          <div class="card-body">
            <h5 class="card-title">Verified Teams</h5>
            <h6 class="card-text"><?php echo e($j); ?></h6>
            <a href="/dashboard/team" class="btn btn-success">View Teams</a>
          </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/dashboard/index.blade.php ENDPATH**/ ?>
<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === '9thNPLC'): ?>
<img src="https://raw.githubusercontent.com/maxx2002/NPLC/main/nplc-regis/public/img/logonplcwhite.png" class="logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>
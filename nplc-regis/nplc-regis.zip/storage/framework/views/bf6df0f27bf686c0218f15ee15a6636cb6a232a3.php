<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/vendor/mail/html/table.blade.php ENDPATH**/ ?>
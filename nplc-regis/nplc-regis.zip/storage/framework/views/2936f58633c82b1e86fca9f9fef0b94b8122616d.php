

<?php $__env->startSection('container'); ?>

<h1 class="mt-4 mb-2">Daftar Tim</h1>

<?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('pesan')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<table class="table table-bordered mt-4">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama Tim</th>
            <th>Asal Sekolah</th>
            <th>Nama Coach</th>
            <th>Email Coach</th>
            <th>No Coach</th>
            <th>Kategori</th>
            <th>Region</th>
            <th>Verified</th>            
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($data->id_tim); ?></td>
            <td><?php echo e($data->nama_tim); ?></td>
            <td><?php echo e($data->nama_sekolah); ?></td>
            <td><?php echo e($data->nama_coach); ?></td>
            <td><?php echo e($data->email_coach); ?></td>            
            <td><?php echo e($data->no_coach); ?></td> 
            <td><?php echo e($data->kategori); ?></td>
            <td><?php echo e($data->region); ?></td>
            <td><?php echo e($data->verified); ?></td>
            <td>
                <a href="/dashboard/team/<?php echo e($data->id_tim); ?>" class="btn btn-sm btn-success">Details</a>  
                <a href="/dashboard/team/edit/<?php echo e($data->id_tim); ?>" class="btn btn-sm btn-warning">Edit</a>  
                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#delete<?php echo e($data->id_tim); ?>">Delete</button> 
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#verified<?php echo e($data->id_tim); ?>">Verified</button>                      
            </td>               
        </tr>                
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="d-flex justify-content-end">
    <?php echo e($team->links()); ?>

</div>

<?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <div class="modal modal-danger fade" id="delete<?php echo e($data->id_tim); ?>" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title">Delete Team <?php echo e($data->nama_tim); ?>?</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <p>Apakah anda yakin ingin menghapus tim <?php echo e($data->nama_tim); ?>?</p>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <a href="/dashboard/team/delete/<?php echo e($data->id_tim); ?>" class="btn btn-danger">Delete</a>
            </div>
        </div>
        </div>
    </div>

    <div class="modal modal-danger fade" id="verified<?php echo e($data->id_tim); ?>" tabindex="-1">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title">Verified Team <?php echo e($data->nama_tim); ?>?</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <p>Apakah anda yakin?</p>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
            <a href="/dashboard/team/verified/<?php echo e($data->id_tim); ?>" class="btn btn-primary">Ya</a>
            </div>
        </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/dashboard/registration/team.blade.php ENDPATH**/ ?>
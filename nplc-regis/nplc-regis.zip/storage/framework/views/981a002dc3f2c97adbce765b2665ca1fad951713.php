

<?php $__env->startSection('container'); ?>

<h3 class="mt-3">Email Sent Successfully</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/dashboard/blast.blade.php ENDPATH**/ ?>
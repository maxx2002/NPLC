

<?php $__env->startSection('container'); ?>

<h1 class="mt-4 mb-2">Team <?php echo e($team->nama_tim); ?></h1>

<?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('pesan')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<table class="table table-bordered mt-4">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Gender</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Kota</th>
            <th>Kode Pos</th>
            <th>Nomor WA</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php ($no=1); ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->gender); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->alamat); ?></td> 
            <td><?php echo e($data->kota); ?></td> 
            <td><?php echo e($data->kode_pos); ?></td> 
            <td><?php echo e($data->no_wa); ?></td> 
            <td>
                <a href="/dashboard/team/member/edit/<?php echo e($data->id_member); ?>" class="btn btn-sm btn-warning">Edit</a>                           
            </td>               
        </tr>                
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="/dashboard/team" class="btn btn-success mt-2">Back</a> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/dashboard/registration/member.blade.php ENDPATH**/ ?>
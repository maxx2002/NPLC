<?php echo e($slot); ?>

<?php /**PATH C:\Users\maxim\Documents\Others (Kuliah)\Student Union\NPLC\Website\github\NPLC\nplc-regis\resources\views/vendor/mail/text/table.blade.php ENDPATH**/ ?>